![Screenshot](https://github.com/mollyhe0523/abc-student-repo/tree/master/projects/mini-projects/5/screenshot.png)

This project intends to tell the person an SOS message every time he/she hits the "What's up" button. The following words on the web would be turned to red and raised the font-size: "help","Help","me","save","Save","Please","please".

Unfortunately I wasn't able to listen to the keyboard action through chrome ime API on the web, so the feature is quite simple here.
